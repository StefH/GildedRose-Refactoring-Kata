namespace GildedRoseKata;

public class SulfurasHandOfRagnarosItem : Item
{
    public SulfurasHandOfRagnarosItem(int sellInDays, int quality) : base("Sulfuras, Hand of Ragnaros", sellInDays, quality)
    {
    }
    
    public override void UpdateQuality()
    {
        // TODO
    }
}